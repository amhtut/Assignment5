namespace GUI_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Add Label Header
            labelheader.Text = "SHAPES";
            labelheader.BorderStyle = BorderStyle.FixedSingle;
            // Add Labels for textboxes
            labellength.Text = "Length: ";
            labelwidth.Text = "Width: ";
            labelheight.Text = "Height: ";
            labelbase.Text = "Base: ";
            labelsidea.Text = "Side A: ";
            labelsideb.Text = "Side B: ";
            label1sidec.Text = "Side C: ";
            // Add text for buttons
            buttonCircle.Text = "Circle";
            buttonTriangle.Text = "Triangle";
            buttonSquare.Text = "Square";
            buttonRectangle.Text = "Rectangle";
            buttonPentagon.Text = "Octagon";
        }
        // Circle button
        // Calculate the perimeter and area of circle
        private void buttonCircle_Click(object sender, EventArgs e)
        {
            double radius, circumference, area;
            string Circumference, Area;
            // Get user input from radius textbox
            radius = int.Parse(textBoxRadius.Text);
            // Calculate the circumference
            circumference = 2 * 3.14 * radius;
            // Calculate the area
            area = 3.14 * radius * radius;
            // Convert the calculation to string
            Circumference = Convert.ToString(circumference);
            Area = Convert.ToString(area);
            // Display results in a MessageBox
            string message = "Circumference is: " + Circumference + "\nArea is: " + Area;
            string title = "Result";
            MessageBox.Show(message, title);
        }
        // Triangle button
        // Calculate the perimeter and area of triangle
        private void buttonTriangle_Click(object sender, EventArgs e)
        {
            double sideA, sideB, sideC, height, Base, perimeter, area;
            string Perimeter, Area;
            // Get user input from SideA, SideB, SideC, Base, and Height textboxes
            sideA = int.Parse(textBoxsidea.Text);
            sideB = int.Parse(textBoxsideb.Text);
            sideC = int.Parse(textBoxsidec.Text);
            Base = int.Parse(textBoxbase.Text);
            height = int.Parse(textBoxheight.Text);
            // Calculate the perimeter
            perimeter = sideA + sideB + sideC;
            // Calculate the area
            area = (height * Base) / 2;
            // Convert the calculation to string
            Area = Convert.ToString(area);
            Perimeter = Convert.ToString(perimeter);
            // Display results in a MessageBox
            string message = "Perimeter is: " + Perimeter + "\nArea is: " + Area;
            string title = "Result";
            MessageBox.Show(message, title);
        }
        // Square button
        // Calculate the perimeter and area of sqaure
        private void buttonRectangle_Click(object sender, EventArgs e)
        {
            double length, width, perimeter, area;
            string Perimeter, Area;
            // Get user input from Length and Width textboxes
            length = int.Parse(textBoxlength.Text);
            width = int.Parse(textBoxwidth.Text);
            // Calculate the perimeter
            perimeter = length + width;
            area = length * width;
            // Convert the calculation to string
            Area = Convert.ToString(area);
            Perimeter = Convert.ToString(perimeter);
            // Display results in a MessageBox
            string message = "Perimeter is: " + Perimeter + "\nArea is: " + Area;
            string title = "Result";
            MessageBox.Show(message, title);
        }
        // Rectangle button
        // Calculate the perimeter and area of rectangle
        private void buttonRectangle_Click_1(object sender, EventArgs e)
        {
            double length, width, perimeter, area;
            string Perimeter, Area;
            // Get user input from Length and Width textboxes
            length = int.Parse(textBoxlength.Text);
            width = int.Parse(textBoxwidth.Text);
            // Calculate the perimeter
            perimeter = length + width;
            // Calculate the area
            area = length * width;
            // Convert the calculation to string
            Area = Convert.ToString(area);
            Perimeter = Convert.ToString(perimeter);
            // Display results in a MessageBox
            string message = "Perimeter is: " + Perimeter + "\nArea is: " + Area;
            string title = "Result";
            MessageBox.Show(message, title);
        }
        // Octagon button
        // Calculate the perimeter and area of octagon
        private void buttonPentagon_Click(object sender, EventArgs e)
        {
            double sideA, perimeter, area;
            string Perimeter, Area;
            // Get user input from SideA textbox
            sideA = int.Parse(textBoxsidepentagon.Text);
            // Calculate the area
            area = 2 * (1 + 1.414) * sideA * sideA;
            // Calculate the perimeter
            perimeter = sideA * 8;
            // Convert the calculation to string
            Area = Convert.ToString(area);
            Perimeter = Convert.ToString(perimeter);
            // Display results in a MessageBox
            string message = "Perimeter is: " + Perimeter + "\nArea is: " + Area;
            string title = "Result";
            MessageBox.Show(message, title);
        }
    }
}
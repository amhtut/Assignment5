﻿namespace GUI_5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelheader = new System.Windows.Forms.Label();
            this.labellength = new System.Windows.Forms.Label();
            this.labelwidth = new System.Windows.Forms.Label();
            this.labelheight = new System.Windows.Forms.Label();
            this.labelbase = new System.Windows.Forms.Label();
            this.labelsidea = new System.Windows.Forms.Label();
            this.labelsideb = new System.Windows.Forms.Label();
            this.label1sidec = new System.Windows.Forms.Label();
            this.textBoxlength = new System.Windows.Forms.TextBox();
            this.textBoxwidth = new System.Windows.Forms.TextBox();
            this.textBoxheight = new System.Windows.Forms.TextBox();
            this.textBoxbase = new System.Windows.Forms.TextBox();
            this.textBoxsidea = new System.Windows.Forms.TextBox();
            this.textBoxsideb = new System.Windows.Forms.TextBox();
            this.textBoxsidec = new System.Windows.Forms.TextBox();
            this.buttonCircle = new System.Windows.Forms.Button();
            this.buttonTriangle = new System.Windows.Forms.Button();
            this.buttonSquare = new System.Windows.Forms.Button();
            this.buttonRectangle = new System.Windows.Forms.Button();
            this.buttonPentagon = new System.Windows.Forms.Button();
            this.labelRadius = new System.Windows.Forms.Label();
            this.textBoxRadius = new System.Windows.Forms.TextBox();
            this.textBoxsidepentagon = new System.Windows.Forms.TextBox();
            this.labelsidepentagon = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelheader
            // 
            this.labelheader.AutoSize = true;
            this.labelheader.Location = new System.Drawing.Point(371, 9);
            this.labelheader.Name = "labelheader";
            this.labelheader.Size = new System.Drawing.Size(43, 15);
            this.labelheader.TabIndex = 0;
            this.labelheader.Text = "header";
            // 
            // labellength
            // 
            this.labellength.AutoSize = true;
            this.labellength.Location = new System.Drawing.Point(453, 48);
            this.labellength.Name = "labellength";
            this.labellength.Size = new System.Drawing.Size(41, 15);
            this.labellength.TabIndex = 2;
            this.labellength.Text = "length";
            // 
            // labelwidth
            // 
            this.labelwidth.AutoSize = true;
            this.labelwidth.Location = new System.Drawing.Point(453, 83);
            this.labelwidth.Name = "labelwidth";
            this.labelwidth.Size = new System.Drawing.Size(37, 15);
            this.labelwidth.TabIndex = 3;
            this.labelwidth.Text = "width";
            // 
            // labelheight
            // 
            this.labelheight.AutoSize = true;
            this.labelheight.Location = new System.Drawing.Point(10, 115);
            this.labelheight.Name = "labelheight";
            this.labelheight.Size = new System.Drawing.Size(41, 15);
            this.labelheight.TabIndex = 4;
            this.labelheight.Text = "height";
            // 
            // labelbase
            // 
            this.labelbase.AutoSize = true;
            this.labelbase.Location = new System.Drawing.Point(10, 150);
            this.labelbase.Name = "labelbase";
            this.labelbase.Size = new System.Drawing.Size(31, 15);
            this.labelbase.TabIndex = 5;
            this.labelbase.Text = "base";
            // 
            // labelsidea
            // 
            this.labelsidea.AutoSize = true;
            this.labelsidea.Location = new System.Drawing.Point(10, 185);
            this.labelsidea.Name = "labelsidea";
            this.labelsidea.Size = new System.Drawing.Size(34, 15);
            this.labelsidea.TabIndex = 6;
            this.labelsidea.Text = "sidea";
            // 
            // labelsideb
            // 
            this.labelsideb.AutoSize = true;
            this.labelsideb.Location = new System.Drawing.Point(10, 220);
            this.labelsideb.Name = "labelsideb";
            this.labelsideb.Size = new System.Drawing.Size(35, 15);
            this.labelsideb.TabIndex = 7;
            this.labelsideb.Text = "sideb";
            // 
            // label1sidec
            // 
            this.label1sidec.AutoSize = true;
            this.label1sidec.Location = new System.Drawing.Point(10, 255);
            this.label1sidec.Name = "label1sidec";
            this.label1sidec.Size = new System.Drawing.Size(34, 15);
            this.label1sidec.TabIndex = 8;
            this.label1sidec.Text = "sidec";
            // 
            // textBoxlength
            // 
            this.textBoxlength.Location = new System.Drawing.Point(500, 45);
            this.textBoxlength.Name = "textBoxlength";
            this.textBoxlength.Size = new System.Drawing.Size(100, 23);
            this.textBoxlength.TabIndex = 9;
            // 
            // textBoxwidth
            // 
            this.textBoxwidth.Location = new System.Drawing.Point(500, 80);
            this.textBoxwidth.Name = "textBoxwidth";
            this.textBoxwidth.Size = new System.Drawing.Size(100, 23);
            this.textBoxwidth.TabIndex = 10;
            // 
            // textBoxheight
            // 
            this.textBoxheight.Location = new System.Drawing.Point(57, 112);
            this.textBoxheight.Name = "textBoxheight";
            this.textBoxheight.Size = new System.Drawing.Size(100, 23);
            this.textBoxheight.TabIndex = 11;
            // 
            // textBoxbase
            // 
            this.textBoxbase.Location = new System.Drawing.Point(57, 147);
            this.textBoxbase.Name = "textBoxbase";
            this.textBoxbase.Size = new System.Drawing.Size(100, 23);
            this.textBoxbase.TabIndex = 12;
            // 
            // textBoxsidea
            // 
            this.textBoxsidea.Location = new System.Drawing.Point(57, 182);
            this.textBoxsidea.Name = "textBoxsidea";
            this.textBoxsidea.Size = new System.Drawing.Size(100, 23);
            this.textBoxsidea.TabIndex = 13;
            // 
            // textBoxsideb
            // 
            this.textBoxsideb.Location = new System.Drawing.Point(57, 217);
            this.textBoxsideb.Name = "textBoxsideb";
            this.textBoxsideb.Size = new System.Drawing.Size(100, 23);
            this.textBoxsideb.TabIndex = 14;
            // 
            // textBoxsidec
            // 
            this.textBoxsidec.Location = new System.Drawing.Point(57, 252);
            this.textBoxsidec.Name = "textBoxsidec";
            this.textBoxsidec.Size = new System.Drawing.Size(100, 23);
            this.textBoxsidec.TabIndex = 15;
            // 
            // buttonCircle
            // 
            this.buttonCircle.Location = new System.Drawing.Point(265, 45);
            this.buttonCircle.Name = "buttonCircle";
            this.buttonCircle.Size = new System.Drawing.Size(75, 23);
            this.buttonCircle.TabIndex = 16;
            this.buttonCircle.Text = "Circle";
            this.buttonCircle.UseVisualStyleBackColor = true;
            this.buttonCircle.Click += new System.EventHandler(this.buttonCircle_Click);
            // 
            // buttonTriangle
            // 
            this.buttonTriangle.Location = new System.Drawing.Point(265, 180);
            this.buttonTriangle.Name = "buttonTriangle";
            this.buttonTriangle.Size = new System.Drawing.Size(75, 23);
            this.buttonTriangle.TabIndex = 17;
            this.buttonTriangle.Text = "Triangle";
            this.buttonTriangle.UseVisualStyleBackColor = true;
            this.buttonTriangle.Click += new System.EventHandler(this.buttonTriangle_Click);
            // 
            // buttonSquare
            // 
            this.buttonSquare.Location = new System.Drawing.Point(687, 45);
            this.buttonSquare.Name = "buttonSquare";
            this.buttonSquare.Size = new System.Drawing.Size(75, 23);
            this.buttonSquare.TabIndex = 18;
            this.buttonSquare.Text = "Square";
            this.buttonSquare.UseVisualStyleBackColor = true;
            this.buttonSquare.Click += new System.EventHandler(this.buttonRectangle_Click);
            // 
            // buttonRectangle
            // 
            this.buttonRectangle.Location = new System.Drawing.Point(687, 80);
            this.buttonRectangle.Name = "buttonRectangle";
            this.buttonRectangle.Size = new System.Drawing.Size(75, 23);
            this.buttonRectangle.TabIndex = 19;
            this.buttonRectangle.Text = "Rectangle";
            this.buttonRectangle.UseVisualStyleBackColor = true;
            this.buttonRectangle.Click += new System.EventHandler(this.buttonRectangle_Click_1);
            // 
            // buttonPentagon
            // 
            this.buttonPentagon.Location = new System.Drawing.Point(687, 180);
            this.buttonPentagon.Name = "buttonPentagon";
            this.buttonPentagon.Size = new System.Drawing.Size(75, 23);
            this.buttonPentagon.TabIndex = 20;
            this.buttonPentagon.Text = "Octagon";
            this.buttonPentagon.UseVisualStyleBackColor = true;
            this.buttonPentagon.Click += new System.EventHandler(this.buttonPentagon_Click);
            // 
            // labelRadius
            // 
            this.labelRadius.AutoSize = true;
            this.labelRadius.Location = new System.Drawing.Point(10, 45);
            this.labelRadius.Name = "labelRadius";
            this.labelRadius.Size = new System.Drawing.Size(42, 15);
            this.labelRadius.TabIndex = 21;
            this.labelRadius.Text = "Radius";
            // 
            // textBoxRadius
            // 
            this.textBoxRadius.Location = new System.Drawing.Point(55, 42);
            this.textBoxRadius.Name = "textBoxRadius";
            this.textBoxRadius.Size = new System.Drawing.Size(100, 23);
            this.textBoxRadius.TabIndex = 22;
            // 
            // textBoxsidepentagon
            // 
            this.textBoxsidepentagon.Location = new System.Drawing.Point(500, 180);
            this.textBoxsidepentagon.Name = "textBoxsidepentagon";
            this.textBoxsidepentagon.Size = new System.Drawing.Size(100, 23);
            this.textBoxsidepentagon.TabIndex = 24;
            // 
            // labelsidepentagon
            // 
            this.labelsidepentagon.AutoSize = true;
            this.labelsidepentagon.Location = new System.Drawing.Point(453, 184);
            this.labelsidepentagon.Name = "labelsidepentagon";
            this.labelsidepentagon.Size = new System.Drawing.Size(34, 15);
            this.labelsidepentagon.TabIndex = 23;
            this.labelsidepentagon.Text = "sidea";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBoxsidepentagon);
            this.Controls.Add(this.labelsidepentagon);
            this.Controls.Add(this.textBoxRadius);
            this.Controls.Add(this.labelRadius);
            this.Controls.Add(this.buttonPentagon);
            this.Controls.Add(this.buttonRectangle);
            this.Controls.Add(this.buttonSquare);
            this.Controls.Add(this.buttonTriangle);
            this.Controls.Add(this.buttonCircle);
            this.Controls.Add(this.textBoxsidec);
            this.Controls.Add(this.textBoxsideb);
            this.Controls.Add(this.textBoxsidea);
            this.Controls.Add(this.textBoxbase);
            this.Controls.Add(this.textBoxheight);
            this.Controls.Add(this.textBoxwidth);
            this.Controls.Add(this.textBoxlength);
            this.Controls.Add(this.label1sidec);
            this.Controls.Add(this.labelsideb);
            this.Controls.Add(this.labelsidea);
            this.Controls.Add(this.labelbase);
            this.Controls.Add(this.labelheight);
            this.Controls.Add(this.labelwidth);
            this.Controls.Add(this.labellength);
            this.Controls.Add(this.labelheader);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelheader;
        private ComboBox comboBox1;
        private Label labellength;
        private Label labelwidth;
        private Label labelheight;
        private Label labelbase;
        private Label labelsidea;
        private Label labelsideb;
        private Label label1sidec;
        private TextBox textBoxlength;
        private TextBox textBoxwidth;
        private TextBox textBoxheight;
        private TextBox textBoxbase;
        private TextBox textBoxsidea;
        private TextBox textBoxsideb;
        private TextBox textBoxsidec;
        private Button buttonCircle;
        private Button buttonTriangle;
        private Button buttonSquare;
        private Button buttonRectangle;
        private Button buttonPentagon;
        private Label labelRadius;
        private TextBox textBoxRadius;
        private TextBox textBoxsidepentagon;
        private Label labelsidepentagon;
    }
}